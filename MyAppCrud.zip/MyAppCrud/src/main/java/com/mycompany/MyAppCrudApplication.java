package com.mycompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyAppCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyAppCrudApplication.class, args);
    }

}
